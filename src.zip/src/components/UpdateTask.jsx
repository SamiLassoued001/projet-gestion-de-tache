// import { useState, useEffect } from "react";
// import {
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   TextField,
//   Button,
//   Stack,
// } from "@mui/material";
// import axios from "axios";

// const UpdatedTask = ({ editTaskData, setEditTaskData, setTasks, socket }) => {
//   const [formData, setFormData] = useState({
//     title: "",
//     content: "",
//     date: "",
//   });

//   useEffect(() => {
//     if (editTaskData) {
//       setFormData({
//         title: editTaskData.title || "",
//         content: editTaskData.content || "",
//         date: editTaskData.date?.slice(0, 10) || "",
//       });
//     }
//   }, [editTaskData]);

//   if (!editTaskData) return null;

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     const { category, _id } = editTaskData;

//     try {
//       const response = await axios.put(`http://localhost:5000/task/tasks/${_id}`, formData);

//       const updatedTask = response.data;

//       setTasks((prev) => {
//         const updated = { ...prev };
//         const index = updated[category].items.findIndex((task) => task._id === _id);
//         if (index !== -1) {
//           updated[category].items[index] = updatedTask;
//         }
//         return updated;
//       });

//       socket.emit("editTask", {
//         category,
//         taskId: _id,
//         ...formData,
//       });

//       setEditTaskData(null);
//     } catch (error) {
//       console.error("❌ Erreur lors de la mise à jour :", error);
//     }
//   };

//   return (
//     <Dialog open={!!editTaskData} onClose={() => setEditTaskData(null)} maxWidth="sm" fullWidth>
//       <DialogTitle>Modifier la tâche</DialogTitle>
//       <form onSubmit={handleSubmit}>
//         <DialogContent>
//           <Stack spacing={2}>
//             <TextField
//               label="Titre"
//               name="title"
//               value={formData.title}
//               onChange={handleChange}
//               required
//               fullWidth
//             />
//             <TextField
//               label="Contenu"
//               name="content"
//               value={formData.content}
//               onChange={handleChange}
//               multiline
//               rows={4}
//               required
//               fullWidth
//             />
//             <TextField
//               label="Date"
//               name="date"
//               type="date"
//               value={formData.date}
//               onChange={handleChange}
//               InputLabelProps={{ shrink: true }}
//               required
//               fullWidth
//             />
//           </Stack>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setEditTaskData(null)} color="secondary">
//             Annuler
//           </Button>
//           <Button type="submit" variant="contained" color="primary">
//             Enregistrer
//           </Button>
//         </DialogActions>
//       </form>
//     </Dialog>
//   );
// };

// export default UpdatedTask;

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Stack,
  MenuItem,
} from "@mui/material";
import axios from "axios";

const UpdatedTask = ({ editTaskData, setEditTaskData, setTasks, socket }) => {
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    date: "",
    category: "", // Ajout du statut
  });

  useEffect(() => {
    if (editTaskData) {
      setFormData({
        title: editTaskData.title || "",
        content: editTaskData.content || "",
        date: editTaskData.date?.slice(0, 10) || "",
        category: editTaskData.category || "todo",
      });
    }
  }, [editTaskData]);

  if (!editTaskData) return null;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { _id, category: oldCategory } = editTaskData;

    try {
      const response = await axios.put(`http://localhost:5000/task/tasks/${_id}`, formData);
      const updatedTask = response.data;
      const newCategory = updatedTask.category;

      setTasks((prev) => {
        const newTasks = { ...prev };

        // Supprimer de l'ancienne catégorie
        newTasks[oldCategory].items = newTasks[oldCategory].items.filter(
          (task) => task._id !== _id
        );

        // Ajouter à la nouvelle catégorie
        if (newTasks[newCategory]) {
          newTasks[newCategory].items = [updatedTask, ...newTasks[newCategory].items];
        }

        return newTasks;
      });

      // Synchronisation avec les autres clients
      socket.emit("fetchTasks");

      // Fermer la modale
      setEditTaskData(null);
    } catch (error) {
      console.error("❌ Erreur lors de la mise à jour :", error);
    }
  };

  return (
    <Dialog open={!!editTaskData} onClose={() => setEditTaskData(null)} maxWidth="sm" fullWidth>
      <DialogTitle>Modifier la tâche</DialogTitle>
      <form onSubmit={handleSubmit}>
        <DialogContent>
          <Stack spacing={2}>
            <TextField
              label="Titre"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
              fullWidth
            />
            <TextField
              label="Contenu"
              name="content"
              value={formData.content}
              onChange={handleChange}
              multiline
              rows={4}
              required
              fullWidth
            />
            <TextField
              label="Date"
              name="date"
              type="date"
              value={formData.date}
              onChange={handleChange}
              InputLabelProps={{ shrink: true }}
              required
              fullWidth
            />
            <TextField
              select
              label="Statut"
              name="category"
              value={formData.category}
              onChange={handleChange}
              fullWidth
              required
            >
              <MenuItem value="todo">À faire</MenuItem>
              <MenuItem value="inProgress">En cours</MenuItem>
              <MenuItem value="done">Terminé</MenuItem>
            </TextField>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditTaskData(null)} color="secondary">
            Annuler
          </Button>
          <Button type="submit" variant="contained" color="primary">
            Enregistrer
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default UpdatedTask;
