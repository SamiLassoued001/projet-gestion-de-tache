import Proffessional  from './Proffessional';
function Proffessionaloffre(){
    return(
        <>
        < Proffessional 
 title={"Déployez plus rapidement "} 
 plans={"TaskFlow Professionnel"} 
 description={"Tâches, délais et projets—restez au courant de tout grâce à l'outil ultime de gestion de projet. Rationalisez votre flux de travail, améliorez la collaboration et boostez votre productivité sans effort. Gardez tout organisé et atteignez vos objectifs avec facilité !" }
 link="https://www.bitrix24.com/upload/optimizer/converted/images/content_en/tools/tasks_and_projects/index/tasks_and_projects-img-block-1.1366w.jpg.webp?1738949454146"
 />
 </>
    )
}
export default Proffessionaloffre;