
import { useEffect, useState } from "react";
import axios from "axios";
import AppLayout from "../components/AppLayout";
import Head from "../components/Head";
import {
  Box,
  Typography,
  Paper,
  Divider,
  Chip,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Alert,
  Stack,
} from "@mui/material";

const TaskDetail = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const user = JSON.parse(localStorage.getItem("user"));

  const fetchTasks = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/task/user/${user?._id}`);
      setTasks(res.data.data);
    } catch (err) {
      console.error("API Error:", err);
      setError("Erreur lors de la récupération des tâches.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  if (loading) {
    return (
      <AppLayout>
        <Box sx={{ p: 4, display: "flex", justifyContent: "center" }}>
          <CircularProgress />
        </Box>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout>
        <Box sx={{ p: 4 }}>
          <Alert severity="error">{error}</Alert>
        </Box>
      </AppLayout>
    );
  }

  if (tasks.length === 0) {
    return (
      <AppLayout>
        <Box sx={{ p: 4 }}>
          <Alert severity="info">Aucune tâche trouvée.</Alert>
        </Box>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <Box sx={{ p: 4 }}>
        <Typography variant="h4" gutterBottom>
          Mes tâches
        </Typography>
        <Stack spacing={3}>
          {tasks.map((task) => (
            <Paper
              key={task._id}
              elevation={3}
              sx={{
                p: 3,
                borderRadius: 2,
                backgroundColor: "#f9f9f9",
              }}
            >
              <Head title={`Détails de la tâche : ${task.title}`} />
              <Typography variant="h6" color="primary" gutterBottom>
                {task.title}
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Typography sx={{ mb: 1 }}>
                <strong>Description :</strong> {task.content}
              </Typography>
              <Typography sx={{ mb: 1 }}>
                <strong>Date :</strong>{" "}
                {new Date(task.date).toLocaleDateString("fr-FR")}
              </Typography>
              <Typography sx={{ mb: 1 }}>
                <strong>Statut :</strong>{" "}
                <Chip
                  label={task.status}
                  color={
                    task.status === "terminé"
                      ? "success"
                      : task.status === "en cours"
                      ? "warning"
                      : "default"
                  }
                  variant="outlined"
                  size="small"
                />
              </Typography>
              <Typography sx={{ mb: 1 }}>
                <strong>Assignée à :</strong>{" "}
                {task.assignedUser?.name || "Non assignée"}
              </Typography>

              {task.comments && task.comments.length > 0 && (
                <Box mt={2}>
                  <Typography variant="subtitle1" gutterBottom>
                    Commentaires :
                  </Typography>
                  <List dense>
                    {task.comments.map((comment, index) => (
                      <ListItem key={comment._id || index} disablePadding>
                        <ListItemText
                          primary={
                            <Typography variant="body2">
                              <strong>{comment.name} :</strong> {comment.text}
                            </Typography>
                          }
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </Paper>
          ))}
        </Stack>
      </Box>
    </AppLayout>
  );
};

export default TaskDetail;

